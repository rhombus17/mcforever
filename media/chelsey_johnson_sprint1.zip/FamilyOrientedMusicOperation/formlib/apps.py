from django.apps import AppConfig


class FormlibConfig(AppConfig):
    name = 'formlib'
