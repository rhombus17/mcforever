# -*- coding:utf-8 -*-
from mako import runtime, filters, cache
UNDEFINED = runtime.UNDEFINED
STOP_RENDERING = runtime.STOP_RENDERING
__M_dict_builtin = dict
__M_locals_builtin = locals
_magic_number = 10
_modified_time = 1516806270.0398173
_enable_loop = True
_template_filename = 'C:/Users/Chelsey/Documents/IS411_413/FOMO/FOMO/FamilyOrientedMusicOperation/homepage/templates/faq.html'
_template_uri = 'faq.html'
_source_encoding = 'utf-8'
import django_mako_plus
_exports = ['head', 'center']


def _mako_get_namespace(context, name):
    try:
        return context.namespaces[(__name__, name)]
    except KeyError:
        _mako_generate_namespaces(context)
        return context.namespaces[(__name__, name)]
def _mako_generate_namespaces(context):
    pass
def _mako_inherit(template, context):
    _mako_generate_namespaces(context)
    return runtime._inherit_from(context, 'app_base.htm', _template_uri)
def render_body(context,**pageargs):
    __M_caller = context.caller_stack._push_frame()
    try:
        __M_locals = __M_dict_builtin(pageargs=pageargs)
        def head():
            return render_head(context._locals(__M_locals))
        def center():
            return render_center(context._locals(__M_locals))
        __M_writer = context.writer()
        __M_writer('\r\n')
        if 'parent' not in context._data or not hasattr(context._data['parent'], 'head'):
            context['self'].head(**pageargs)
        

        __M_writer('\r\n')
        if 'parent' not in context._data or not hasattr(context._data['parent'], 'center'):
            context['self'].center(**pageargs)
        

        return ''
    finally:
        context.caller_stack._pop_frame()


def render_head(context,**pageargs):
    __M_caller = context.caller_stack._push_frame()
    try:
        def head():
            return render_head(context)
        __M_writer = context.writer()
        __M_writer('\r\n    <h1 class="center-head">Frequently Asked Questions</h1>\r\n')
        return ''
    finally:
        context.caller_stack._pop_frame()


def render_center(context,**pageargs):
    __M_caller = context.caller_stack._push_frame()
    try:
        def center():
            return render_center(context)
        __M_writer = context.writer()
        __M_writer('\r\n<p>\r\n<hr>\r\n<b>When will I receive my order?</b><br />\r\n<br />\r\nIn stock,  non-pre-order items shipping to addresses within the United States are sent by UPS or US Mail (USPS) depending on weight and usually take 7-10 business day to arrive. APO addresses have an average transit time of 10-21 days. International shipments including Canada and Mexico are made via international post (mail) and take up to 21 business days to arrive. International shipments may be held by your local Customs Authority for an additional 10-14 days depending on the customs laws in your country. Therefore, it is best to allow 4-6 weeks for delivery. <br />\r\n<br />\r\nOrders received over the weekend and on holidays will be processed the following business day. In most cases, your credit card will not be charged until the product is shipped. We will notify you if any item cannot be shipped within 30 days and you will be given the option to cancel your order.<br />\r\n<br />\r\nA Note To Customers Living Outside the United States <br />\r\n<br />\r\nIf you order products for delivery to a shipping address outside the United States, you will be responsible for any and all import taxes, tariffs and duties which may be levied by your Customs or Government or Other Authority upon any parcel we send to you. Please note: taxes/duties are calculated based on the original retail price of the items in your order and does not include any discounts or promotions.<br />\r\n<br />\r\nIf you do not receive your order within the time frames above, please contact Customer Service using the form on the Contact Us page<br />\r\n<hr>\r\n<b>I never received my confirmation e-mail after ordering/registering/shipment.</b><br />\r\n<br />\r\nPlease check your Spam box — 99% of the time, you will find it there. It’s also possible that you entered the wrong email address. If you still have problems, go back to the store, navigate to the “Contact Us” page, and send us an email.<br />\r\n<hr>\r\n<b>How do I contact customer service?</b><br />\r\n<br />\r\nYou can contact us at the “Contact Us” page. Unfortunately we are unable to assist via phone.<br />\r\n<hr>\r\n</p>\r\n')
        return ''
    finally:
        context.caller_stack._pop_frame()


"""
__M_BEGIN_METADATA
{"filename": "C:/Users/Chelsey/Documents/IS411_413/FOMO/FOMO/FamilyOrientedMusicOperation/homepage/templates/faq.html", "uri": "faq.html", "source_encoding": "utf-8", "line_map": {"28": 0, "37": 1, "42": 4, "52": 2, "58": 2, "64": 5, "70": 5, "76": 70}}
__M_END_METADATA
"""
