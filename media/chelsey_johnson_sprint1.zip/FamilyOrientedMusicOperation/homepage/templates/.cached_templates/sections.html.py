# -*- coding:utf-8 -*-
from mako import runtime, filters, cache
UNDEFINED = runtime.UNDEFINED
STOP_RENDERING = runtime.STOP_RENDERING
__M_dict_builtin = dict
__M_locals_builtin = locals
_magic_number = 10
_modified_time = 1516937714.8739388
_enable_loop = True
_template_filename = 'C:/Users/Chelsey/Documents/IS411_413/FOMO/FOMO/FamilyOrientedMusicOperation/homepage/templates/sections.html'
_template_uri = 'sections.html'
_source_encoding = 'utf-8'
import django_mako_plus
_exports = ['head', 'left', 'center', 'right', 'foot']


def _mako_get_namespace(context, name):
    try:
        return context.namespaces[(__name__, name)]
    except KeyError:
        _mako_generate_namespaces(context)
        return context.namespaces[(__name__, name)]
def _mako_generate_namespaces(context):
    pass
def _mako_inherit(template, context):
    _mako_generate_namespaces(context)
    return runtime._inherit_from(context, 'app_base.htm', _template_uri)
def render_body(context,**pageargs):
    __M_caller = context.caller_stack._push_frame()
    try:
        __M_locals = __M_dict_builtin(pageargs=pageargs)
        def center():
            return render_center(context._locals(__M_locals))
        def foot():
            return render_foot(context._locals(__M_locals))
        def left():
            return render_left(context._locals(__M_locals))
        def right():
            return render_right(context._locals(__M_locals))
        def head():
            return render_head(context._locals(__M_locals))
        __M_writer = context.writer()
        __M_writer('\r\n\r\n\r\n')
        if 'parent' not in context._data or not hasattr(context._data['parent'], 'head'):
            context['self'].head(**pageargs)
        

        __M_writer('\r\n\r\n')
        if 'parent' not in context._data or not hasattr(context._data['parent'], 'left'):
            context['self'].left(**pageargs)
        

        __M_writer('\r\n\r\n')
        if 'parent' not in context._data or not hasattr(context._data['parent'], 'center'):
            context['self'].center(**pageargs)
        

        __M_writer('\r\n\r\n')
        if 'parent' not in context._data or not hasattr(context._data['parent'], 'right'):
            context['self'].right(**pageargs)
        

        __M_writer('\r\n\r\n')
        if 'parent' not in context._data or not hasattr(context._data['parent'], 'foot'):
            context['self'].foot(**pageargs)
        

        __M_writer('\r\n\r\n')
        return ''
    finally:
        context.caller_stack._pop_frame()


def render_head(context,**pageargs):
    __M_caller = context.caller_stack._push_frame()
    try:
        def head():
            return render_head(context)
        __M_writer = context.writer()
        __M_writer('\r\n    <div id="red">\r\n        <p>Donec posuere, sapien sed placerat rhoncus, neque odio eleifend odio, ut interdum nisi augue eget lectus. Aliquam scelerisque, nibh vel rhoncus fermentum, nibh ante fermentum felis, et lacinia ex leo et massa. Proin efficitur risus at est aliquam, non suscipit justo egestas. Proin at elit euismod, aliquet velit vitae, aliquet sapien. Morbi aliquet nunc id enim pulvinar dapibus id ut arcu.</p>\r\n    </div>\r\n')
        return ''
    finally:
        context.caller_stack._pop_frame()


def render_left(context,**pageargs):
    __M_caller = context.caller_stack._push_frame()
    try:
        def left():
            return render_left(context)
        __M_writer = context.writer()
        __M_writer('\r\n    <div id="blue">\r\n       <p>Donec posuere, sapien sed placerat rhoncus, neque odio eleifend odio, ut interdum nisi augue eget lectus. Aliquam scelerisque, nibh vel rhoncus fermentum, nibh ante fermentum felis, et lacinia ex leo et massa. Proin efficitur risus at est aliquam, non suscipit justo egestas. Proin at elit euismod, aliquet velit vitae, aliquet sapien. Morbi aliquet nunc id enim pulvinar dapibus id ut arcu. Mauris eleifend pulvinar consequat. Praesent nec malesuada mauris. Sed blandit id tortor et rhoncus. Morbi maximus ipsum non ligula placerat, vitae feugiat massa tristique. Donec fringilla non risus sed porta.Donec posuere, sapien sed placerat rhoncus, neque odio eleifend odio, ut interdum nisi augue eget lectus. Aliquam scelerisque, nibh vel rhoncus fermentum, nibh ante fermentum felis, et lacinia ex leo et massa. Proin efficitur risus at est aliquam, non suscipit justo egestas. Proin at elit euismod, aliquet velit vitae, aliquet sapien. Morbi aliquet nunc id enim pulvinar dapibus id ut arcu. Mauris eleifend pulvinar consequat. Praesent nec malesuada mauris. Sed blandit id tortor et rhoncus. Morbi maximus ipsum non ligula placerat, vitae feugiat massa tristique. Donec fringilla non risus sed porta.Donec posuere, sapien sed placerat rhoncus, neque odio eleifend odio, ut interdum nisi augue eget lectus. Aliquam scelerisque, nibh vel rhoncus fermentum, nibh ante fermentum felis, et lacinia ex leo et massa. Proin efficitur risus at est aliquam, non suscipit justo egestas. Proin at elit euismod, aliquet velit vitae, aliquet sapien. Morbi aliquet nunc id enim pulvinar dapibus id ut arcu. Mauris eleifend pulvinar consequat. Praesent nec malesuada mauris. Sed blandit id tortor et rhoncus. Morbi maximus ipsum non ligula placerat, vitae feugiat massa tristique. Donec fringilla non risus sed porta.Donec posuere, sapien sed placerat rhoncus, neque odio eleifend odio, ut interdum nisi augue eget lectus. Aliquam scelerisque, nibh vel rhoncus fermentum, nibh ante fermentum felis, et lacinia ex leo et massa. Proin efficitur risus at est aliquam, non suscipit justo egestas. Proin at elit euismod, aliquet velit vitae, aliquet sapien. Morbi aliquet nunc id enim pulvinar dapibus id ut arcu. Mauris eleifend pulvinar consequat. Praesent nec malesuada mauris. Sed blandit id tortor et rhoncus. Morbi maximus ipsum non ligula placerat, vitae feugiat massa tristique. Donec fringilla non risus sed porta.Donec posuere, sapien sed placerat rhoncus, neque odio eleifend odio, ut interdum nisi augue eget lectus. Aliquam scelerisque, nibh vel rhoncus fermentum, nibh ante fermentum felis, et lacinia ex leo et massa. Proin efficitur risus at est aliquam, non suscipit justo egestas. Proin at elit euismod, aliquet velit vitae, aliquet sapien. Morbi aliquet nunc id enim pulvinar dapibus id ut arcu. Mauris eleifend pulvinar consequat. Praesent nec malesuada mauris. Sed blandit id tortor et rhoncus. Morbi maximus ipsum non ligula placerat, vitae feugiat massa tristique. Donec fringilla non risus sed porta.Donec posuere, sapien sed placerat rhoncus, neque odio eleifend odio, ut interdum nisi augue eget lectus. Aliquam scelerisque, nibh vel rhoncus fermentum, nibh ante fermentum felis, et lacinia ex leo et massa. Proin efficitur risus at est aliquam, non suscipit justo egestas. Proin at elit euismod, aliquet velit vitae, aliquet sapien. Morbi aliquet nunc id enim pulvinar dapibus id ut arcu. Mauris eleifend pulvinar consequat. Praesent nec malesuada mauris. Sed blandit id tortor et rhoncus. Morbi maximus ipsum non ligula placerat, vitae feugiat massa tristique. Donec fringilla non risus sed porta.Donec posuere, sapien sed placerat rhoncus, neque odio eleifend odio, ut interdum nisi augue eget lectus. Aliquam scelerisque, nibh vel rhoncus fermentum, nibh ante fermentum felis, et lacinia ex leo et massa. Proin efficitur risus at est aliquam, non suscipit justo egestas. Proin at elit euismod, aliquet velit vitae, aliquet sapien. Morbi aliquet nunc id enim pulvinar dapibus id ut arcu. Mauris eleifend pulvinar consequat. Praesent nec malesuada mauris. Sed blandit id tortor et rhoncus. Morbi maximus ipsum non ligula placerat, vitae feugiat massa tristique. Donec fringilla non risus sed porta.Donec posuere, sapien sed placerat rhoncus, neque odio eleifend odio, ut interdum nisi augue eget lectus. Aliquam scelerisque, nibh vel rhoncus fermentum, nibh ante fermentum felis, et lacinia ex leo et massa. Proin efficitur risus at est aliquam, non suscipit justo egestas. Proin at elit euismod, aliquet velit vitae, aliquet sapien. Morbi aliquet nunc id enim pulvinar dapibus id ut arcu. Mauris eleifend pulvinar consequat. Praesent nec malesuada mauris. Sed blandit id tortor et rhoncus. Morbi maximus ipsum non ligula placerat, vitae feugiat massa tristique. Donec fringilla non risus sed porta.Donec posuere, sapien sed placerat rhoncus, neque odio eleifend odio, ut interdum nisi augue eget lectus. Aliquam scelerisque, nibh vel rhoncus fermentum, nibh ante fermentum felis, et lacinia ex leo et massa. Proin efficitur risus at est aliquam, non suscipit justo egestas. Proin at elit euismod, aliquet velit vitae, aliquet sapien. Morbi aliquet nunc id enim pulvinar dapibus id ut arcu. Mauris eleifend pulvinar consequat. Praesent nec malesuada mauris. Sed blandit id tortor et rhoncus. Morbi maximus ipsum non ligula placerat, vitae feugiat massa tristique. Donec fringilla non risus sed porta.</p>\r\n    </div>\r\n')
        return ''
    finally:
        context.caller_stack._pop_frame()


def render_center(context,**pageargs):
    __M_caller = context.caller_stack._push_frame()
    try:
        def center():
            return render_center(context)
        __M_writer = context.writer()
        __M_writer('\r\n    <div id="green">\r\n        <p>Donec in faucibus ante, sed ullamcorper enim. Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas. Duis ac laoreet diam, et vestibulum ligula. Integer ullamcorper mattis odio. Nulla faucibus odio in ipsum cursus consectetur. Etiam non augue lacus. Duis ut ex ac ligula tempus faucibus. Phasellus mollis cursus mauris, non finibus orci. Quisque euismod diam condimentum lacus tincidunt ultrices.</p>\r\n    </div>\r\n')
        return ''
    finally:
        context.caller_stack._pop_frame()


def render_right(context,**pageargs):
    __M_caller = context.caller_stack._push_frame()
    try:
        def right():
            return render_right(context)
        __M_writer = context.writer()
        __M_writer('\r\n    <div id="yellow">\r\n        <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nunc ut erat sit amet ipsum dictum posuere bibendum ac neque. Proin accumsan ex eget volutpat iaculis. Nullam venenatis sapien id tellus pharetra, id bibendum augue porttitor. Fusce quis vulputate est. Integer eleifend tempor justo eu auctor. Sed aliquam gravida leo, in posuere odio tincidunt ut. Fusce posuere eleifend nibh, condimentum pellentesque dolor dictum non. Etiam non urna ultrices, blandit sapien at, blandit lectus. Aenean accumsan scelerisque imperdiet.</p>\r\n    </div>\r\n')
        return ''
    finally:
        context.caller_stack._pop_frame()


def render_foot(context,**pageargs):
    __M_caller = context.caller_stack._push_frame()
    try:
        def foot():
            return render_foot(context)
        __M_writer = context.writer()
        __M_writer('\r\n    <div id="orange">\r\n        <p>hi</p>\r\n    </div>\r\n')
        return ''
    finally:
        context.caller_stack._pop_frame()


"""
__M_BEGIN_METADATA
{"filename": "C:/Users/Chelsey/Documents/IS411_413/FOMO/FOMO/FamilyOrientedMusicOperation/homepage/templates/sections.html", "uri": "sections.html", "source_encoding": "utf-8", "line_map": {"28": 0, "43": 1, "48": 8, "53": 14, "58": 20, "63": 26, "68": 32, "74": 4, "80": 4, "86": 10, "92": 10, "98": 16, "104": 16, "110": 22, "116": 22, "122": 28, "128": 28, "134": 128}}
__M_END_METADATA
"""
