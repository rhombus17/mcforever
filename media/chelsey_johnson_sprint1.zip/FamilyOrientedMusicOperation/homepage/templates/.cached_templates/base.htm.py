# -*- coding:utf-8 -*-
from mako import runtime, filters, cache
UNDEFINED = runtime.UNDEFINED
STOP_RENDERING = runtime.STOP_RENDERING
__M_dict_builtin = dict
__M_locals_builtin = locals
_magic_number = 10
_modified_time = 1516760764.4822435
_enable_loop = True
_template_filename = 'C:/Users/Chelsey/Documents/IS411_413/FOMO/FOMO/FamilyOrientedMusicOperation/homepage/templates/base.htm'
_template_uri = 'base.htm'
_source_encoding = 'utf-8'
import django_mako_plus
_exports = ['SpecialMessage', 'navigation', 'head', 'left', 'center', 'right', 'footer']


def render_body(context,**pageargs):
    __M_caller = context.caller_stack._push_frame()
    try:
        __M_locals = __M_dict_builtin(pageargs=pageargs)
        STATIC_URL = context.get('STATIC_URL', UNDEFINED)
        def navigation():
            return render_navigation(context._locals(__M_locals))
        def SpecialMessage():
            return render_SpecialMessage(context._locals(__M_locals))
        self = context.get('self', UNDEFINED)
        def right():
            return render_right(context._locals(__M_locals))
        def footer():
            return render_footer(context._locals(__M_locals))
        def left():
            return render_left(context._locals(__M_locals))
        def head():
            return render_head(context._locals(__M_locals))
        def center():
            return render_center(context._locals(__M_locals))
        __M_writer = context.writer()
        __M_writer('<!DOCTYPE html>\r\n<html>\r\n    <meta charset="UTF-8">\r\n    <head>\r\n\r\n        <title>Family Oriented Music Operation</title>\r\n\r\n')
        __M_writer('        \r\n        <script src="http://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>\r\n        <link rel="stylesheet" type="text/css" href="')
        __M_writer(str( STATIC_URL))
        __M_writer('homepage/media//bootstrap/css/bootstrap.min.css?33192040">\r\n        <link rel="stylesheet" type="text/css" href="')
        __M_writer(str( STATIC_URL))
        __M_writer('homepage/media/bootstrap/css/theme.min.css?33192040">\r\n        <script src="')
        __M_writer(str( STATIC_URL))
        __M_writer('homepage/media/bootstrap/js/bootstrap.min.js">\r\n        <link rel="icon" href="')
        __M_writer(str( STATIC_URL ))
        __M_writer('homepage/media/icon.png"\r\n')
        __M_writer('        <script src="/django_mako_plus/dmp-common.min.js"></script>\r\n        ')
        __M_writer(str( django_mako_plus.links(self) ))
        __M_writer('\r\n\r\n    </head>\r\n    <body>\r\n        ')
        if 'parent' not in context._data or not hasattr(context._data['parent'], 'SpecialMessage'):
            context['self'].SpecialMessage(**pageargs)
        

        __M_writer('\r\n        \r\n        ')
        if 'parent' not in context._data or not hasattr(context._data['parent'], 'navigation'):
            context['self'].navigation(**pageargs)
        

        __M_writer('\r\n\r\n        <header>\r\n            ')
        if 'parent' not in context._data or not hasattr(context._data['parent'], 'head'):
            context['self'].head(**pageargs)
        

        __M_writer('\r\n        </header> \r\n        <div class="container-fluid maincontent">\r\n            <div class="row">\r\n                <div class="col-md-3">\r\n                    ')
        if 'parent' not in context._data or not hasattr(context._data['parent'], 'left'):
            context['self'].left(**pageargs)
        

        __M_writer('\r\n                </div>\r\n                <div class="col-md-6">\r\n                    ')
        if 'parent' not in context._data or not hasattr(context._data['parent'], 'center'):
            context['self'].center(**pageargs)
        

        __M_writer('\r\n                </div>\r\n                <div class="col-md-3">\r\n                    ')
        if 'parent' not in context._data or not hasattr(context._data['parent'], 'right'):
            context['self'].right(**pageargs)
        

        __M_writer('\r\n                </div>\r\n            </div>\r\n        </div>\r\n        ')
        if 'parent' not in context._data or not hasattr(context._data['parent'], 'footer'):
            context['self'].footer(**pageargs)
        

        __M_writer('\r\n    </body>\r\n</html>\r\n')
        return ''
    finally:
        context.caller_stack._pop_frame()


def render_SpecialMessage(context,**pageargs):
    __M_caller = context.caller_stack._push_frame()
    try:
        def SpecialMessage():
            return render_SpecialMessage(context)
        __M_writer = context.writer()
        return ''
    finally:
        context.caller_stack._pop_frame()


def render_navigation(context,**pageargs):
    __M_caller = context.caller_stack._push_frame()
    try:
        def navigation():
            return render_navigation(context)
        __M_writer = context.writer()
        return ''
    finally:
        context.caller_stack._pop_frame()


def render_head(context,**pageargs):
    __M_caller = context.caller_stack._push_frame()
    try:
        def head():
            return render_head(context)
        __M_writer = context.writer()
        __M_writer('\r\n            ')
        return ''
    finally:
        context.caller_stack._pop_frame()


def render_left(context,**pageargs):
    __M_caller = context.caller_stack._push_frame()
    try:
        def left():
            return render_left(context)
        __M_writer = context.writer()
        __M_writer('\r\n                    ')
        return ''
    finally:
        context.caller_stack._pop_frame()


def render_center(context,**pageargs):
    __M_caller = context.caller_stack._push_frame()
    try:
        def center():
            return render_center(context)
        __M_writer = context.writer()
        __M_writer('\r\n                    ')
        return ''
    finally:
        context.caller_stack._pop_frame()


def render_right(context,**pageargs):
    __M_caller = context.caller_stack._push_frame()
    try:
        def right():
            return render_right(context)
        __M_writer = context.writer()
        __M_writer('\r\n                    ')
        return ''
    finally:
        context.caller_stack._pop_frame()


def render_footer(context,**pageargs):
    __M_caller = context.caller_stack._push_frame()
    try:
        def footer():
            return render_footer(context)
        __M_writer = context.writer()
        __M_writer('\r\n        ')
        return ''
    finally:
        context.caller_stack._pop_frame()


"""
__M_BEGIN_METADATA
{"filename": "C:/Users/Chelsey/Documents/IS411_413/FOMO/FOMO/FamilyOrientedMusicOperation/homepage/templates/base.htm", "uri": "base.htm", "source_encoding": "utf-8", "line_map": {"17": 0, "38": 2, "39": 10, "40": 12, "41": 12, "42": 13, "43": 13, "44": 14, "45": 14, "46": 15, "47": 15, "48": 17, "49": 18, "50": 18, "55": 22, "60": 24, "65": 28, "70": 34, "75": 38, "80": 42, "85": 47, "91": 22, "102": 24, "113": 27, "119": 27, "125": 33, "131": 33, "137": 37, "143": 37, "149": 41, "155": 41, "161": 46, "167": 46, "173": 167}}
__M_END_METADATA
"""
